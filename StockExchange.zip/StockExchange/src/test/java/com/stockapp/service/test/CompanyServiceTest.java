package com.stockapp.service.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.stockapp.entity.Company;
import com.stockapp.repository.ICompanyDao;
import com.stockapp.service.ICompanyServiceImpl;

@SpringBootTest
public class CompanyServiceTest {

	@Autowired
	private ICompanyServiceImpl companyService;

	@MockBean
	private ICompanyDao companyRepository;

	@Test
	@DisplayName("Test for adding company")
	public void addCompanyTest() {
		Company company = new Company(100, "Amazon" );
	when(companyRepository.save(company)).thenReturn(company);
		assertEquals(true, companyService.addCompanyInfo(company));
	}

	@Test
	@DisplayName("Test for updating company")
	public void updateCompanyTest() {
		Company company = new Company(100, "Amazon");
		when(companyRepository.save(company)).thenReturn(company);
	//	assertEquals(true, companyService.updateCompany(company));
		
		company.setCompanyName("Aazon.in");
		assertThat(companyRepository.findById(company.getCompanyId())).isNotEqualTo(company);
	}

	@Test
	@DisplayName("Test for deleting company")
	public void removeCompanyTest() {
		
	//	companyService.deleteCompany("A100");
	//	verify(companyRepository, times(1)).deleteById("A100");
		Company company = new Company(100, "Amazon");
		
		when(companyRepository.existsById(company.getCompanyId())).thenReturn(true);
		companyService.deleteCompanyInfo(company.getCompanyId());
		verify(companyRepository).deleteById(100);
	}

	@Test
	@DisplayName("Test for displaying all companies")
	public void showAllCompanyTest() {
		when(companyRepository.findAll())
				.thenReturn(Stream.of(new Company(100, "Amazon"))
					.collect(Collectors.toList()));
		assertEquals(1, companyService.getAllCompanyInfo().size());
	}

	@Test
	@DisplayName("Test for displaying company by Id")
	public void showCompanyTest() {
		
		Company company = new Company(100, "Amazon");
		when(companyRepository.save(company)).thenReturn(company);
		assertNotEquals(company,companyRepository.findById(company.getCompanyId()));
			
	}

}
