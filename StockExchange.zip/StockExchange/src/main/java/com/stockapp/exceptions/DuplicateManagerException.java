package com.stockapp.exceptions;

public class DuplicateManagerException extends RuntimeException {
	
	public DuplicateManagerException(String message) {
		super(message);
	}

}
