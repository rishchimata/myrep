package com.stockapp.exceptions;

public class EmptyTableException extends RuntimeException {
		
		public EmptyTableException(String message) {
			super(message);
		}
		
	}


