package com.stockapp.exceptions;

public class InsufficientSharesException extends RuntimeException{

	public InsufficientSharesException(String msg) {
		super(msg);
	}
}
