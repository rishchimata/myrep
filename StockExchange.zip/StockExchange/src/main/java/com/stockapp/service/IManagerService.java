package com.stockapp.service;


import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.stockapp.entity.Company;
import com.stockapp.entity.Manager;
@Service
public interface IManagerService {

	public boolean addManager(Manager info);
		public List<Manager> getAllManager();
		public Optional<Manager> getManagerDetails(int managerId);
		public boolean updateManager(Manager info);
		public boolean deleteManager(int managerId);
		public Manager getManager(Company company);

}
