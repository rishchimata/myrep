package com.stockapp.service;

import org.springframework.stereotype.Service;

import com.stockapp.entity.User;

@Service
public interface IUserService
{

	public User login(String username,String password);
	public String logout(User user);
	public boolean createUser(User user);
	public boolean updateUser( User user);
	public boolean removeUser(User user);
	
	
}
