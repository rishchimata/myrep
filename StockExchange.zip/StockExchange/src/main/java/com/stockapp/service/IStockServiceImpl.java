package com.stockapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stockapp.entity.Company;
import com.stockapp.entity.Investor;
import com.stockapp.entity.Stock;
import com.stockapp.entity.Transaction;
import com.stockapp.exceptions.CompanyNotFoundException;
import com.stockapp.exceptions.DuplicateStockException;
import com.stockapp.exceptions.EmptyTableException;
import com.stockapp.exceptions.InvestorNotFoundException;
import com.stockapp.exceptions.StockNotFoundException;
import com.stockapp.repository.ICompanyDao;
import com.stockapp.repository.IStockDAO;
import com.stockapp.repository.ITransactionDao;
import com.stockapp.repository.InvestorDao;

//import com.cg.stockapp.dao.ICompanyDao;
//import com.cg.stockapp.dao.IStockDAO;
//import com.cg.stockapp.dao.ITransactionDao;
//import com.cg.stockapp.dao.InvestorDao;
//import com.cg.stockapp.dto.Company;
//import com.cg.stockapp.dto.Investor;
//import com.cg.stockapp.dto.Stock;
//import com.cg.stockapp.dto.Transaction;
//import com.cg.stockapp.exceptions.CompanyNotFoundExceptions;
//import com.cg.stockapp.exceptions.DuplicateStockExceptions;
//import com.cg.stockapp.exceptions.EmptyTableExceptions;
//import com.cg.stockapp.exceptions.InvestorNotFoundExceptions;
//import com.cg.stockapp.exceptions.StockNotFoundExceptions;

@Service
public class IStockServiceImpl implements IStockService {

	@Autowired
	IStockDAO stockDao;
	
	@Autowired
	ICompanyDao companyDao;
	
	@Autowired
	InvestorDao investorDao;
	
	@Autowired
	ITransactionDao transactionDao;
	Logger log = LoggerFactory.getLogger(IStockServiceImpl.class);

	//Add Stock details
	@Override
	public boolean addStockDetails(Stock stock) {
		// TODO Auto-generated method stub
		log.info("Stock object: "+stock);
		log.info("addStock() has been invoked");
		int companyId = stock.getCompany().getCompanyId();
//		if(!companyDao.existsById(companyId)) {
//			log.warn("CompanyNotFoundExceptions : Creation failed, compnay not found with id "+companyId);
//			throw new CompanyNotFoundException("Creation", "Company not found with id "+companyId);
//		}
		if (stockDao.existsById(stock.getStockId())) {
			log.warn("DuplicateStockException : Stock already exists with id "+stock.getStockId());
			throw new DuplicateStockException("Stock already exists with id " + stock.getStockId());
		}
		else {
			stockDao.save(stock);
			log.info("A new Stock has been added for the company "+stock.getCompany().getCompanyName());
			return true;
		}
	}

	@Override
	public boolean updateStockDetails(Stock stock) {
		// TODO Auto-generated method stub
		log.info("updateStock() has been invoked");
		int companyId = stock.getCompany().getCompanyId();
		if(!companyDao.existsById(companyId)) {
			log.warn("CompanyNotFoundException : Update failed, compnay not found with id "+companyId);
			throw new CompanyNotFoundException("Update", "Company not found with id "+companyId);
		}
		if (stockDao.existsById(stock.getStockId())) {
			int stockid=stock.getStockId();
			double exist_stockprice =stockDao.findExistStockprice(stockid);
			double new_stockprice =stock.getAvgPrice();
			log.info("exist db price: " +exist_stockprice);
			log.info("new ob price: " +new_stockprice);
			log.info("updateStock() has been invoked");
			if(new_stockprice>exist_stockprice) {
				double profit=new_stockprice-exist_stockprice;
				stock.setProfitLoss(profit);
				//stock.setType("REDUCING");
				stock.setType("GROWING");
			} else if(exist_stockprice>new_stockprice) {
				double loss=new_stockprice-exist_stockprice;
				stock.setProfitLoss(loss);
				//stock.setType("GROWING");
				stock.setType("REDUCING");
			}  else {
				//stock.setProfitLoss(loss);
				stock.setType("NEUTRAL");
			}
			
			stockDao.save(stock);
			log.info("A stock with id "+stock.getStockId()+" has been updated");
			return true;
		}
		else {
			log.warn("StockNotFoundException : Update"
					+ " failed, Stock not found with id "+stock.getStockId());
			throw new StockNotFoundException("Update", "Stock not found with id "+stock.getStockId());
		}
		//return null;
	}

	@Override
	public boolean removeStockDetails(int stockId) {
		// TODO Auto-generated method stub
		log.info("removeStock() has been invoked");
		if (stockDao.existsById(stockId)) {
			stockDao.deleteById(stockId);
			log.info("A stock with id "+stockId+" has been removed");
			return true;
		}
		else {
			log.warn("StockNotFoundException : Delete failed, Stock not found with id "+stockId);
			throw new StockNotFoundException("Delete", "Stock not found with id "+stockId);
		}
		
	}

	@Override
	public Stock viewStockDetails(int stockId) {
		log.info("viewStockDetails() has been invoked");
		if(stockDao.existsById(stockId)) {
			log.info("A stock has been returned with id "+stockId);
			return stockDao.findById(stockId).get();
		}
		else {
			log.warn("StockNotFoundException : Request failed, stock not found with id "+stockId);
			throw new StockNotFoundException("Request", "Stock not found with id "+stockId);
		}
	}

	@Override
	public List<Stock> viewAllStockDetails() {
		// TODO Auto-generated method stub
		log.info("viewAllStock() has been invoked");
		if (stockDao.findAll().isEmpty()) {
			log.warn("EmptyTableException : No data found in the database");
			throw new EmptyTableException("No Data Found in the database");
		}
		else {
			log.info("All stocks returned");
			return stockDao.findAll();
		}
		
	}

	@Override
	public List<Stock> viewStockByCompanyName(String companyName) {
		// TODO Auto-generated method stub
		log.info("viewStockByCompany() has been invoked");
		if(!companyDao.existsByCompanyName(companyName)) {
			log.warn("CompanyNotFoundException : Request failed, campany not found with name "+companyName);
			throw new CompanyNotFoundException("Request", "Company not found with name "+companyName);
		}
		
		Company company = companyDao.findByCompanyName(companyName);
		List<Stock> stockList = stockDao.findByCompany(company);
		
		if(stockList.isEmpty()) {
			log.warn("StockNotFoundException : Rquest failed, no stock found for the company "+companyName);
			throw new StockNotFoundException("Request", "No stock found for the company "+companyName);
		}
		else {
			log.info("All stock returned for the company "+companyName);
			return stockList;
		}
	}

	@Override
	public List<Stock> viewStockByInvestor(Investor inv) {
		// TODO Auto-generated method stub
		log.info("viewStockByInvestor() has been invoked");
		int investorId = inv.getInvestorId();
		if(!investorDao.existsById(investorId)) {
			log.warn("InvestorNotFoundException : Fetch failed, Investor not found with id "+investorId);
			throw new InvestorNotFoundException("Retrieve", "Investor not found with id "+investorId);
		}
		if (investorDao.existsById(investorId)) {
			log.info("A stock has been returned with id "+investorId);
			Investor investor = investorDao.findById(investorId).get();
			
			List<Integer> stockId=transactionDao.findAll().stream()
									.filter(transaction -> transaction.getInvestorId()==inv.getInvestorId())
									.map(Transaction :: getStockId).collect(Collectors.toList());
			List<Stock> investorStocks=new ArrayList<Stock>();
			for(int id:stockId) {
				Stock stock=stockDao.findById(id).get();
				investorStocks.add(stock);
			}
//			List<Stock> investorStocks = investor.getTransactions()
//													 .stream()
//													 .map(t->t.getStock())
//													 .collect(Collectors.toList());
			if(investorStocks.isEmpty()) {
				log.warn("StockNotFoundException : Fetch failed, Stock not found for investor with id "+inv.getInvestorId());
				throw new StockNotFoundException("Retrieve", "Stock not found for investor with id "+inv.getInvestorId());
			}
				return investorStocks;
			}
		return null;
		}
//		else {
//			log.warn("StockNotFoundException : Fetch failed, Stock not found for investor with id "+inv.getInvestorId());
//			throw new StockNotFoundException("Retrieve", "Stock not found for investor with id "+inv.getInvestorId());
//		}
		//return null;
	

	@Override
	public List<Stock> viewAllGrowingStocks() {
		// TODO Auto-generated method stub
		log.info("viewAllGrowingStocks() has been invoked");
		//log.info("limit value"+limit);
//		List<Stock> stock = stockDao.findTopNStocks(limit);
		List<Stock> stock = stockDao.findGrowingReducingStocks("GROWING");
		//List<Stock> stock = stockDao.findTopNStocks();
		return stock;
//		List<Transaction> transaction = transactionDao.findTopGrowingStocks(limit);
//		List<Stock> growingStocks = transaction
//				 .stream()
//				 .map(t->t.getStock())
//				 .collect(Collectors.toList());
//				return growingStocks;

	}
	
	

	@Override
	public List<Stock> viewAllReducingStocks() {
		// TODO Auto-generated method stub
		log.info("viewAllReducingStocks() has been invoked");
		//List<Transaction> transaction = transactionDao.findTopGrowingStocks(limit);
		List<Stock> stock = stockDao.findGrowingReducingStocks("REDUCING");
//		List<Stock> reducingStocks = transaction
//				 .stream()
//				 .map(t->t.getStock())
//				 .collect(Collectors.toList());
//				return reducingStocks;
		return stock;
		//return null;
	}

	@Override
	public Stock viewStockDetails(Stock stock) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean removeStockDetails(Stock stock) {
		// TODO Auto-generated method stub
		return true;
	}
}
