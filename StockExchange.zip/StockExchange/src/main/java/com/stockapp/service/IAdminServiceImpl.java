package com.stockapp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stockapp.entity.Admin;
import com.stockapp.exceptions.AdminNotFoundException;
import com.stockapp.exceptions.DuplicateAdminException;
import com.stockapp.repository.IAdminDao;
import com.stockapp.repository.IUserDao;


@Service
public class IAdminServiceImpl implements IAdminService {

	@Autowired
	IAdminDao adminDao;

	@Autowired
	IUserDao userDao;

	public static final Logger LOGGER = LoggerFactory.getLogger(IAdminServiceImpl.class);

	@Override
	public List<Admin> getAdmins() {
		// TODO Auto-generated method stub
		List<Admin> la = adminDao.findAll();
		return la;
	}

	@Override
	public Admin getAdmin(int adminId) {
		// TODO Auto-generated method stub

		LOGGER.info("getAdmin() has been invoked");
		if (adminDao.existsById(adminId)) {
			{LOGGER.info("Admin with id " + adminId + "has been returned");}
			return adminDao.findById(adminId).get();
		} else {
			LOGGER.warn("AdminNotFoundException thrown... Request failed, Admin not found with id " + adminId);
			throw new AdminNotFoundException("Request", "Admin not found with id " + adminId);
		}
	}

	@Override
	public boolean addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		//System.out.println(admin);
		LOGGER.info("addAdmin() has been invoked");
		if (adminDao.existsById(admin.getAdminId())) {
			LOGGER.warn("DuplicateAdminException thrown... Creation failed, Admin already exists with id "+ admin.getAdminId());
			throw new DuplicateAdminException("Admin already exists with id " + admin.getAdminId());
		}
		else 
		{
			adminDao.save(admin);
			LOGGER.info("A new Admin has been added with id " + admin.getAdminId());
			return true;
		}
		// return admin;
	}

	@Override
	public boolean deleteAdmin(int adminId) {
		// TODO Auto-generate method stub
		if (adminDao.existsById(adminId)) {
			adminDao.deleteById(adminId);
			return true;
		} else {
			LOGGER.warn("AdminNotFoundException thrown... Delete failed, Admin not found with id " + adminId);
			throw new AdminNotFoundException("Delete", "Admin not found with id " + adminId);
		}
	}
	//
	@Override
	public boolean updateAdmin(Admin admin) {
		// TODO Auto-generated method stub
	
		LOGGER.info("Admin id " + admin.getAdminId());
		
		LOGGER.info("updateAdmin() has been invoked");
		
		if (adminDao.existsById(admin.getAdminId())) {
			adminDao.save(admin);
			LOGGER.info("Admin with id " + admin.getAdminId() + " has been updated");
			return true;
		} else {
			throw new AdminNotFoundException("Update", "Admin not found with id " + admin.getAdminId());
		}
	}
}
