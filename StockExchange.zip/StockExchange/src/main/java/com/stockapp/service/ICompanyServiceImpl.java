package com.stockapp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stockapp.exceptions.CompanyNotFoundException;
import com.stockapp.exceptions.DuplicateCompanyException;
import com.stockapp.exceptions.EmptyTableException;
import com.stockapp.repository.ICompanyDao;
import com.stockapp.entity.Company;

@Service
public class ICompanyServiceImpl implements ICompanyService {

	@Autowired
	ICompanyDao companyDao;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(Company.class);
	
	

	@Override
	public boolean addCompanyInfo(Company info) {
		LOGGER.info("addCompany() has been invoked");
		if (companyDao.existsById(info.getCompanyId())) {
			LOGGER.warn("DuplicateCompanyException : Company already exists with id " + info.getCompanyId());
			throw new DuplicateCompanyException("Company already exists with id " + info.getCompanyId());
		//return false;
		}
		else {
			
		companyDao.save(info);
		LOGGER.info("New Company added");
		return true;
		
	}
		//return false;

	}
	@Override
	public List<Company> getAllCompanyInfo() {
		List<Company> companyList = companyDao.findAll();
		if(companyList.isEmpty()) {
			LOGGER.warn("No data found in the database");
			throw new EmptyTableException("No Data Found ");
		}
		else {
			LOGGER.info("All companies details returned");
		return companyList;
		}
		//return null;
	}

	@Override
	public Company getCompanyDetails(int companyId) {
		LOGGER.info("getCompanyInfo() has been invoked");
		if (companyDao.existsById(companyId)) {
			LOGGER.info("Company returned with id " + companyId);
			return companyDao.findById(companyId).get();
		} else {
			LOGGER.warn("CompanyNotFoundException : Request failed, Company not found with id " + companyId);
			throw new CompanyNotFoundException("Request", "Company not found with id " + companyId);
		}
		// TODO Auto-generated method stub
		//return null;
		
	}

	@Override
	public boolean updateCompanyInfo(Company info) {
		LOGGER.info("updateCompany() has been invoked");
		if (companyDao.existsById(info.getCompanyId())) {
			companyDao.save(info);
			LOGGER.info("Company updated with id "+info.getCompanyId());
			return true;
		} else {
			LOGGER.warn("CompanyNotFoundException : Update failed, Company not found with id "+info.getCompanyId());
			throw new CompanyNotFoundException("Update", "Company not found with id " + info.getCompanyId());
		//return false;
		}
	}

	@Override
	public boolean deleteCompanyInfo(int companyId) {
		
		LOGGER.info("deleteCompany() has been invoked");
		  if
		  (companyDao.existsById(companyId)) 
		  { 
			  companyDao.deleteById(companyId);
			  LOGGER.info("Company deleted with id "+companyId);
			  return true; 
		 } else {
			 LOGGER.warn("CompanyNotFoundException : Delete failed, Company not found with id "+companyId);
			 throw new CompanyNotFoundException("Delete", "Company not found with id " + companyId);
		 }
		
		 
		//return false;
	}
	
		

		
}
