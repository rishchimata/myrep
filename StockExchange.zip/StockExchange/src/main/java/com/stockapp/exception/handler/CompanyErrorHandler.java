package com.stockapp.exception.handler;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.stockapp.exceptions.CompanyNotFoundException;
import com.stockapp.exceptions.DuplicateCompanyException;
import com.stockapp.exceptions.EmptyTableException;
//import com.cg.stockapp.dto.Company;


@ControllerAdvice
	public class CompanyErrorHandler extends ResponseEntityExceptionHandler{
	
	Logger log = LoggerFactory.getLogger(CompanyErrorHandler.class);
		
		@ExceptionHandler(DuplicateCompanyException.class)
		public ResponseEntity<?> handleDuplicateCompanyException(DuplicateCompanyException dce) {
			Map<String, Object> errorbody = new LinkedHashMap<>();
			errorbody.put("error", "Creation failed");
			errorbody.put("timestamp", LocalDateTime.now());
			errorbody.put("details", dce.getMessage());
			log.info("addCompany() has been invoked");
			return new ResponseEntity<>(errorbody, HttpStatus.ALREADY_REPORTED);
		}
		
		@ExceptionHandler(CompanyNotFoundException.class)
		public ResponseEntity<?> handleMissingCompanyException(CompanyNotFoundException cne) {
			Map<String, Object> errorbody = new LinkedHashMap<>();
			errorbody.put("error", cne.getOperation()+" failed");
			errorbody.put("timestamp", LocalDateTime.now());
			errorbody.put("details", cne.getMessage());
			log.info(cne.getMessage());
			log.info(cne.getOperation());
			
			return new ResponseEntity<>(errorbody, HttpStatus.NOT_FOUND);
		}
		@ExceptionHandler(EmptyTableException.class)
		public ResponseEntity<?> handleMissingEmptyTableException(EmptyTableException cne) {
			Map<String, Object> errorbody = new LinkedHashMap<>();
			errorbody.put("error"," failed");
			errorbody.put("timestamp", LocalDateTime.now());
			errorbody.put("details", cne.getMessage());
			log.info(cne.getMessage());
		//	log.info(cne.getOperation());
			
			return new ResponseEntity<>(errorbody, HttpStatus.NOT_FOUND);
		}

}
