package com.stockapp.exception.handler;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.stockapp.exceptions.InvestorNotFoundException;



@ControllerAdvice
public class InvestorExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(InvestorNotFoundException.class)
	public ResponseEntity<?> handleMissingInvestor(InvestorNotFoundException ine){
		Map<String, Object> errorBody=new HashMap<String, Object>();
		errorBody.put("timestamp",LocalDateTime.now());
		errorBody.put("message", ine.getMessage());
		
		return new ResponseEntity<> (errorBody,HttpStatus.NOT_FOUND);
	}
}
