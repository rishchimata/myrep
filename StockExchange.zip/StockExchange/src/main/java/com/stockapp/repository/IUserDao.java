package com.stockapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.stockapp.entity.User;

@Repository
public interface IUserDao extends JpaRepository<User, Integer>
{

	User findByUserNameAndPassword(String username, String password);

//	public User login(String userName,String password);
//	public User logout(User user);
//	public User createUser(User user);
//	public User removeUser(User user);
	
}
