package com.stockapp.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stockapp.entity.Company;
import com.stockapp.entity.Manager;


@Repository
public interface IManagerDao extends JpaRepository<Manager, Integer>{

	Manager findByCompany(Company company);

//	public boolean addManager(Manager info);
//	public List<Manager> getAllManager();
//	public Manager getManagerDetails(String managerId);
//	public Manager UpdateManager(Manager info);
//	public Manager deleteManager(String managerId);
//	public Manager getManager(Company company);
}
