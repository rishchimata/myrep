package com.stockapp.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockapp.entity.Admin;
import com.stockapp.service.IAdminServiceImpl;

@CrossOrigin(origins = "http://localhost:4200")
@RestController

@RequestMapping("/admin")
//@CrossOrigin(origins = "http://localhost:9090")
public class AdminController {

	@Autowired
	IAdminServiceImpl adminServiceImpl;
	

	@GetMapping
	public List<Admin> getAllAdmin() {
		return adminServiceImpl.getAdmins();
	}
	
	@GetMapping("{adminId}")
	public Admin getAdmin(@PathVariable("adminId") int adminId) {
		return adminServiceImpl.getAdmin(adminId);
	}
	

	@PostMapping 
	public ResponseEntity<?> addAdmin(@Valid @RequestBody Admin admin,BindingResult result) {
		System.out.println(admin);
		if(result.hasErrors())
		return new ResponseEntity<List<String>>(result.getFieldErrors().stream().map(FieldError::getDefaultMessage).collect(Collectors.toList()),HttpStatus.BAD_REQUEST);
		adminServiceImpl.addAdmin(admin);
		return new ResponseEntity<>("Admin added successfully",HttpStatus.OK);
		}
	
	@PutMapping
	public ResponseEntity<?> updateAdmin(@Valid @RequestBody Admin admin, BindingResult result) {
		if(result.hasErrors())
		return new ResponseEntity<List<String>>(result.getFieldErrors().stream().map(FieldError::getDefaultMessage).collect(Collectors.toList()),HttpStatus.OK);
		adminServiceImpl.updateAdmin(admin);
		return new ResponseEntity<String>("Admin with id "+admin.getAdminId()+" updated successfully",HttpStatus.OK);
	}
	

	@DeleteMapping("{adminId}")
	public String removeAdmin(@PathVariable("adminId") int adminId) {
		adminServiceImpl.deleteAdmin(adminId);
		return "Admin with id "+adminId+" has been removed successfully";
	}
}