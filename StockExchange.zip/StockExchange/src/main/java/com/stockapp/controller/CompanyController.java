package com.stockapp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockapp.entity.Company;
import com.stockapp.service.ICompanyServiceImpl;

@RestController
@RequestMapping("/company")
public class CompanyController {

	@Autowired
	ICompanyServiceImpl companyServiceImpl;
	
	@PostMapping
	public String addCompanyInfo(@Valid @RequestBody Company company) {
		companyServiceImpl.addCompanyInfo(company);
		return "Company added successfully";
	}
	
	@GetMapping("{companyId}")
	public Company getCompanyInfo(@PathVariable("companyId") int companyId) {
		return companyServiceImpl.getCompanyDetails(companyId);
	}
		
	@GetMapping
	public List<Company> getAllCompanyInfo(){
		return companyServiceImpl.getAllCompanyInfo();
	}
	
	@PutMapping
	public String updateCompanyInfo(@Valid @RequestBody Company company) {
		companyServiceImpl.updateCompanyInfo(company);
		return "Company with id"+company.getCompanyId();
	}
	
	@DeleteMapping("{companyId}")
	public String deleteCompanyInfo(@PathVariable("companyId") int companyId) {
		companyServiceImpl.deleteCompanyInfo(companyId);
		return "Company with id "+companyId+" deleted successfully";
	}
}
