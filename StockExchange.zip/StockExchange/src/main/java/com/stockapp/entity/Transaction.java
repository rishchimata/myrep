package com.stockapp.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Transaction {

	@Id
	@GeneratedValue
	private int transactionId;
	
	private LocalDateTime trasanctionDate;
	private String trasanctionType;
	
	private int stockId;
	private int investorId;
	private int quantity;

	
	public Transaction() {
		super();
	}

	public Transaction(LocalDateTime trasanctionDate, String trasanctionType, int stockId,
			int investorId, int quantity) {
		super();
		this.trasanctionDate = trasanctionDate;
		this.trasanctionType = trasanctionType;
		this.stockId = stockId;
		this.investorId = investorId;
		this.quantity = quantity;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public LocalDateTime getTrasanctionDate() {
		return trasanctionDate;
	}

	public void setTrasanctionDate(LocalDateTime trasanctionDate) {
		this.trasanctionDate = trasanctionDate;
	}

	public String getTrasanctionType() {
		return trasanctionType;
	}

	public void setTrasanctionType(String trasanctionType) {
		this.trasanctionType = trasanctionType;
	}
	
	public int getQuantity() {
		return quantity;
	}

	public int getStockId() {
		return stockId;
	}

	public void setStockId(int stockId) {
		this.stockId = stockId;
	}

	public int getInvestorId() {
		return investorId;
	}

	public void setInvestorId(int investorId) {
		this.investorId = investorId;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", trasanctionDate=" + trasanctionDate
				+ ", trasanctionType=" + trasanctionType + ", stockId=" + stockId + ", investorId=" + investorId
				+ ", quantity=" + quantity + "]";
	}
	
	
}
