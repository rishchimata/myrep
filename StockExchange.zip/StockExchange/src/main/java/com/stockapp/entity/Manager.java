package com.stockapp.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sun.istack.NotNull;

@Entity
public class Manager {
	@GeneratedValue
	@Id
	@Column(name = "MANAGER_ID", nullable = false)
	private int managerId;
	
	@NotNull
	@Length(min = 5, max = 20, message = "Username should be from 5 to 20 characters")
	@Column(name = "MANAGER_NAME")
	private String managerName;	
	
	@Autowired
	@OneToOne(targetEntity = Company.class, cascade=CascadeType.ALL)	
    @JoinColumn(name = "companyId")
	//@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" })
	private  Company company;
	
	@NotNull
	@Pattern(regexp = "^[A-Za-z0-9._]+@[A-za-z0-9]+[.][A-za-z]{2,5}$", message = "Email is not valid")
	@Column(name = "EMAIL")
	private String email;
	
	@Pattern(regexp = "[0-9]{10}", message = "Invalid mobile number")
	@Column(name = "MOBILE_NUM" )
	private String mobileNo;
	
	public Manager() {
		super();
	}

	public Manager(int managerId, String managerName, String email,  String mobileNum, Company company) {
		super();
		this.managerId = managerId;
		this.managerName = managerName;
		this.email = email;
		this.mobileNo = mobileNum;
		this.company = company;
	}

	public int getManagerId() {
		return managerId;
	}
	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "Manager [managerId=" + managerId + ", managerName=" + managerName + ", email=" + email + ", mobileNo="
				+ mobileNo + "]";
	}
	
	
}
