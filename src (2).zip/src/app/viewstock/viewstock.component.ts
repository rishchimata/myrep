import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StockService } from '../stock.service';

@Component({
  selector: 'app-viewstock',
  templateUrl: './viewstock.component.html',
  styleUrls: ['./viewstock.component.css']
})
export class ViewstockComponent implements OnInit {
  stock:any;
  constructor(private service:StockService,private router: Router) { }

  ngOnInit(): void {
    let stock=this.service.fetchStock();
    stock.subscribe((data)=>this.stock=data)
    alert(stock);
  }

  public removeStock(id:number){
    alert(id);
    let stock=this.service.deleteStock(id);
    stock.subscribe((data)=>this.stock=data)
    location.reload();
  }
  updateStock(id:number):void{
    this.router.navigate(['updatestock',id]);
  }
}
