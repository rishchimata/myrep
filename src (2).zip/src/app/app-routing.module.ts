import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddAdminComponent } from './add-admin/add-admin.component';
import { AddCompanyComponent } from './add-company/add-company.component';
import { AddManagerComponent } from './add-manager/add-manager.component';
import { AddUserComponent } from './add-user/add-user.component';
import { AuthGaurdService } from './authService/auth-gaurd.service';
import { AddInvestorComponent } from './components/Investor/Add/add-investor.component';
import { BuyStockComponent } from './components/Investor/BuyStock/buy-stock.component';
import { InvestorDashboardComponent } from './components/Investor/Dashboard/investor-dashboard.component';
import { SellStockComponent } from './components/Investor/SellStock/sell-stock.component';
import { UpdateInvestorComponent } from './components/Investor/Update/update-investor.component';
import { ViewInvestorComponent } from './components/Investor/View/view-investor.component';
import { ViewInvestorByCompanyComponent } from './components/Investor/ViewByCompany/view-investor-by-company.component';
import { ViewInvestorByStockComponent } from './components/Investor/ViewByStock/view-investor-by-stock.component';
import { GrowingstockComponent } from './growingstock/growingstock.component';
import { LoginComponent } from './login/login.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { ReducingstockComponent } from './reducingstock/reducingstock.component';
import { RegisterComponent } from './register/register.component';
import { StockComponent } from './stock/stock.component';
import { StockbycompanyComponent } from './stockbycompany/stockbycompany.component';
import { StockbyinvestorComponent } from './stockbyinvestor/stockbyinvestor.component';
import { UpdateAdminComponent } from './update-admin/update-admin.component';
import { UpdateCompanyComponent } from './update-company/update-company.component';
import { UpdateManagerComponent } from './update-manager/update-manager.component';
import { UpdatestockComponent } from './updatestock/updatestock.component';
import { ViewAdminComponent } from './view-admin/view-admin.component';
import { ViewCompanyComponent } from './view-company/view-company.component';
import { ViewManagerComponent } from './view-manager/view-manager.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { ViewstockComponent } from './viewstock/viewstock.component';

const routes: Routes = [
  { path: '', component: AddAdminComponent,canActivate:[AuthGaurdService] },
  { path: 'login', component: LoginComponent },
  { path: 'addAdmin', component: AddAdminComponent },//canActivate:[AuthGaurdService] },
  { path: 'viewAdmin', component: ViewAdminComponent },
  { path: 'updateAdmin/:id', component: UpdateAdminComponent },

  { path: 'main', component: MainpageComponent },
  { path: 'addstock', component: StockComponent }, 
  { path: 'updatestock/:id', component: UpdatestockComponent },
  { path: 'viewstock', component: ViewstockComponent },
  { path: 'stockbyinvestor', component: StockbyinvestorComponent },
  { path: 'stockbycompany', component: StockbycompanyComponent },
  { path: 'reducingstock', component: ReducingstockComponent },
  { path: 'growingstock', component: GrowingstockComponent },
  // for manager 
  { path: 'addManager', component: AddManagerComponent },
  { path: 'viewManager', component: ViewManagerComponent },
  { path: 'updateManager/:id', component: UpdateManagerComponent },

  // for company
  {path: 'addcompany', component: AddCompanyComponent }, 
  { path: 'updateCompany/:id', component: UpdateCompanyComponent },
  { path: 'viewcompany', component: ViewCompanyComponent },

  // for user
  {path: 'register', component: RegisterComponent},
  {path: 'addUser', component: AddUserComponent},
  {path: 'viewUser', component: ViewUserComponent},
  //{path: 'login', component: LoginComponent}

  // for investor
  { path: 'addInvestor' , component: AddInvestorComponent },
  { path: 'investorDashboard' , component: InvestorDashboardComponent },
  { path: 'getAllInvestor' , component: ViewInvestorComponent },
  { path: 'getInvestorDetails/:investorId' , component: UpdateInvestorComponent },
  { path: 'viewAllInvestorByStock/:stockId' , component: ViewInvestorByStockComponent },
  { path: 'viewAllInvestorByCompany/:companyId' , component: ViewInvestorByCompanyComponent },
  { path: 'buyStock/:stockId/:investorId/:quantity' , component: BuyStockComponent },
  { path: 'sellStock/:stockId/:investorId/:quantity' , component: SellStockComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
