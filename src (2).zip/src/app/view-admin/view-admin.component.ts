import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../adminservice/admin.service';

@Component({
  selector: 'app-view-admin',
  templateUrl: './view-admin.component.html',
  styleUrls: ['./view-admin.component.css']
})
export class ViewAdminComponent implements OnInit {
  admins:any;

  constructor(private service:AdminService,private router: Router) { }

  ngOnInit(): void {
    let admin=this.service.fetchAdmin();
    admin.subscribe((data)=>this.admins=data)
  }
public removeAdmin(id:number){
  let admin=this.service.deleteAdmin(id);
  admin.subscribe((data)=>this.admins=data)
  location.reload();
}
updateAdmin(id:number):void{
  this.router.navigate(['updateAdmin',id]);
}
}
