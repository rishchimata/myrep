import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ManagerService } from '../manager.service';

@Component({
  selector: 'app-view-manager',
  templateUrl: './view-manager.component.html',
  styleUrls: ['./view-manager.component.css']
})
export class ViewManagerComponent implements OnInit {
  managers:any;

  constructor(private service:ManagerService,private router: Router) { }

  ngOnInit(): void {
    let manager=this.service.fetchManager();
    manager.subscribe((data)=>this.managers=data)
  }
public removeManager(id:number){
  let manager=this.service.deleteManager(id);
  manager.subscribe((data)=>this.managers=data)
  location.reload();
}
updateManager(id:number):void{
  this.router.navigate(['updateManager',id]);
}
  

}
