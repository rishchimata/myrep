import { Component, OnInit } from '@angular/core';
import { Company } from '../company';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-add-company',
  templateUrl: './add-company.component.html',
  styleUrls: ['./add-company.component.css']
})
export class AddCompanyComponent implements OnInit {
company: Company=new Company(0,"");
msg:any;
companys:any;
  constructor(private service:CompanyService) { }

  ngOnInit(): void {
  }
public insert() {
  //alert (JSON.stringify(this.company));
  let response=this.service.insertCompany(this.company);
  response.subscribe((data)=>this.msg=data);
}
}
