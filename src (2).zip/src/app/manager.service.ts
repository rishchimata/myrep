import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Manager } from './manager';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ManagerService {

  constructor(private http:HttpClient) { }
  public insertManager(manager:any){
    alert(JSON.stringify(manager));
    return this.http.post("http://localhost:9091/manager",manager,{responseType:'text'})
  }
  public fetchManager(){
    return this.http.get("http://localhost:9091/manager");
  }
  public deleteManager(id:number){
    return this.http.delete("http://localhost:9091/manager/"+id);
  }
  public  getManagerById(mid:number):Observable<Manager>{
    return this.http.get<Manager>("http://localhost:9091/manager/"+mid);
  }
  public updateManager(manager:Manager):Observable<Manager>
  {
    return this.http.put<Manager>("http://localhost:9091/manager",manager);
  }
  public insertCompany(company:any) {
    alert(JSON.stringify(company));
    return this.http.post("http://localhost:9091/company",company,{responseType: 'text'});

  }
  public fetchCompany() {
    return this.http.get("http://localhost:9091/company");

  }
}
