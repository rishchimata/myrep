export class Transaction {
    constructor(
        investorId: number,
        quantity: number,
        stockId: number,
        transactionId: number,
        trasanctionDate: Date,
        trasanctionType: string
    ){}
}
