import { Company } from "./company";

export class Stock {
    constructor(
        public avgPrice: number,
        public company: Company,
        public profitLoss: number,
        public quantity: number,
        public status: string,
        public stockId: number,
        public stockName: string,
        public totalStocks: number,
        public type: string
    ){}
}
