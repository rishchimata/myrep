import { Investor } from './investor';

describe('Investor', () => {
  it('should create an instance', () => {
    expect(new Investor()).toBeTruthy();
  });
});
