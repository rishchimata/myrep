import { Bank } from './bank';

describe('Bank', () => {
  it('should create an instance', () => {
    expect(new Bank()).toBeTruthy();
  });
});
