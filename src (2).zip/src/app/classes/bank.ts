export class Bank {
    constructor(
        public accountNo: number,
        public bankName: string,
        public branchName: string,
        public ifscCode: number,
    ){}
}
