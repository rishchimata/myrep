import { Bank } from "./bank";

export class Investor {

    constructor(
        public account:Bank,
        public email: string,
        public gender: string,
        public investorId: number,
        public investorName: string,
        public mobileNo: number
    ){}
}
