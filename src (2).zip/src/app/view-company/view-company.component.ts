import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-view-company',
  templateUrl: './view-company.component.html',
  styleUrls: ['./view-company.component.css']
})
export class ViewCompanyComponent implements OnInit {
  companys:any;

  constructor(private service:CompanyService,private router: Router) { }

  ngOnInit(): void {
    let company=this.service.fetchCompany();
    company.subscribe((data)=>this.companys=data)
  }
  public removeCompany(id:number){
    let admin=this.service.deleteCompany(id);
    admin.subscribe((data)=>this.companys=data)
    location.reload();
  }
  updateCompany(id:number):void{
    this.router.navigate(['updateCompany',id]);
  }
}
