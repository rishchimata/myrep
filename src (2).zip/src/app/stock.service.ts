import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Stock } from './stock';
import { Company } from './company';
@Injectable({
  providedIn: 'root'
})
export class StockService {

  constructor(private http:HttpClient) { }


  // for adding the stock data 
  public insertStock(stock:any) {
    alert(JSON.stringify(stock));
    return this.http.post("http://localhost:9091/stock",stock,{responseType: 'text'})
  }

  public fetchStock() {
    return this.http.get("http://localhost:9091/stock");

  }
  public deleteStock(id:number){
    alert(id);
    return this.http.delete("http://localhost:9091/stock/"+id);
  }
  public  getStockById(sid:number):Observable<Stock>{
    return this.http.get<Stock>("http://localhost:9091/stock/"+sid);
  }
  public updateStock(stock:Stock):Observable<Stock>
  {
    return this.http.put<Stock>("http://localhost:9091/stock",stock);
  }
  public  getStockByInvestor(iid:number):Observable<Stock>{
    return this.http.get<Stock>("http://localhost:9091/stock/"+iid);
  }
  public  getStockByCompany(cname:string):Observable<Stock>{
      // let cname=company.companyName;
    return this.http.get<Stock>("http://localhost:9091/stock/company/"+cname);
  }
  public  getReducingStock():Observable<Stock>{
    return this.http.get<Stock>("http://localhost:9091/stock/reducingstock");
  }
  public  getGrowingStock():Observable<Stock>{
    return this.http.get<Stock>("http://localhost:9091/stock/growingstock");
  }
}
