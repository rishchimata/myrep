export class Company {
    constructor(
        public companyId:number,
        public companyName:string
        ) {}
}
