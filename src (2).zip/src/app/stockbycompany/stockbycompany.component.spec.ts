import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StockbycompanyComponent } from './stockbycompany.component';

describe('StockbycompanyComponent', () => {
  let component: StockbycompanyComponent;
  let fixture: ComponentFixture<StockbycompanyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StockbycompanyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StockbycompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
