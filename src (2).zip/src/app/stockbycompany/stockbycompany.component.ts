import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Company } from '../company';
import { Stock } from '../stock';
import { StockService } from '../stock.service';

@Component({
  selector: 'app-stockbycompany',
  templateUrl: './stockbycompany.component.html',
  styleUrls: ['./stockbycompany.component.css']
})
export class StockbycompanyComponent implements OnInit {

  UStock!:Observable<Stock>;
  //stock!: Stock;
  stock:any;
  company!:Company;
   isfetched:boolean = false;
   companyname!:string;
  constructor(private route: ActivatedRoute,private router: Router,
    private service: StockService) { }
    
  ngOnInit(): void {
     
  }
  selectChangeHandler (event: any) {
    //update the ui
    this.companyname = event.target.value;
  }

  onSubmit() {
    this.UStock=this.service.getStockByCompany(this.companyname);
    this.UStock.subscribe((data)=>this.stock=data)
    if(this.stock){
      this.isfetched=true;
    }
    console.log(this.stock);
  // this.UStock.subscribe(data=>{alert("Please Enter Valid Data for Stock");},
  // error => alert("Stock by company successfully."));
  //location.reload();
  }

}
