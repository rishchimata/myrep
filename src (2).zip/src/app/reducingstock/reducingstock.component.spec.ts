import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReducingstockComponent } from './reducingstock.component';

describe('ReducingstockComponent', () => {
  let component: ReducingstockComponent;
  let fixture: ComponentFixture<ReducingstockComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReducingstockComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReducingstockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
