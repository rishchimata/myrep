import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StockService } from '../stock.service';

@Component({
  selector: 'app-reducingstock',
  templateUrl: './reducingstock.component.html',
  styleUrls: ['./reducingstock.component.css']
})
export class ReducingstockComponent implements OnInit {
  stock:any;
  constructor(private service:StockService,private router: Router) { }

  ngOnInit(): void {
    let stock=this.service.getReducingStock();
    stock.subscribe((data)=>this.stock=data)
  }

}
