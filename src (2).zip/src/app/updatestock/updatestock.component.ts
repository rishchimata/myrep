import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Company } from '../company';
import { Stock } from '../stock';
import { StockService } from '../stock.service';

@Component({
  selector: 'app-updatestock',
  templateUrl: './updatestock.component.html',
  styleUrls: ['./updatestock.component.css']
})
export class UpdatestockComponent implements OnInit {
  id!:number;
  stock!: Stock;
  company!:Company;
  UStock!:Observable<Stock>;
  sid!:string;
  constructor(private route: ActivatedRoute,private router: Router,
    private service: StockService) { }

  ngOnInit(): void {
    this.sid = this.route.snapshot.params['id'];
    this.id=Number.parseInt(this.sid);
    this.company=new Company(0,"");
    this.stock= new Stock(0,"",0,"NEUTRAL",0,0,0,"ACTIVE",this.company);
    console.log(this.id);
    this.service.getStockById(this.id).subscribe(data => {
      console.log(data);
      //alert(data);
      this.stock=data;
    }, error => console.log(error));
  }

  onSubmit() {
    
    this.UStock=this.service.updateStock(this.stock);
  this.UStock.subscribe(data=>{alert("Please Enter Valid Data for Stock");},
  error => alert("Stock updated successfully."));
  this.router.navigate(['/viewstock']);
  }
  list(){
    this.router.navigate(['viewstock']);
  }
}
