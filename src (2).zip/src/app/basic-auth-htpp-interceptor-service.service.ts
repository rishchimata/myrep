import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BasicAuthHtppInterceptorService implements HttpInterceptor {

  constructor() { }

  intercept(req: HttpRequest<any>, next: HttpHandler):Observable<HttpEvent<any>> {


     {

      if (sessionStorage.getItem('username') && sessionStorage.getItem('token')) {
        let token = sessionStorage.getItem('token');
      //let token = 'Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqYXZhand0IiwiZXhwIjoxNjMxNjk5NTA5LCJpYXQiOjE2MzE2ODE1MDl9.EeSiXHXfKcOz64SyU67_nD2GvD-a2-YV4RObzuiEGUOypjwkC4RCbwy03tspVegIKxx93_t-SQ9JryKSnEQi5w-qweea'
        let modified_req = req.clone({ setHeaders: { 'Authorization': ` ${token}` } });
        alert(`Bearer ${token}`);
        return next.handle(modified_req);
          }
          else
          {
           
             return next.handle(req);
          }

  }
  }}