import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Company } from './company';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {
  

  constructor(private http:HttpClient) 
  { }
  public insertCompany(company:any) {
    alert(JSON.stringify(company));
    return this.http.post("http://localhost:9091/company",company,{responseType: 'text'})
  }
  public fetchCompany() {
    return this.http.get("http://localhost:9091/company");

  }
  public deleteCompany(id:number){
    return this.http.delete("http://localhost:9091/company/"+id);
  }
  public  getCompanyById(cid:number):Observable<Company>{
    return this.http.get<Company>("http://localhost:9091/company/"+cid);
  }
  public updateCompany(company:Company):Observable<Company>
  {
    return this.http.put<Company>("http://localhost:9091/company",company);
  }
}
