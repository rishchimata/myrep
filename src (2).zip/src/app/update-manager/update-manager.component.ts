import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Manager } from '../manager';
import { ManagerService } from '../manager.service';

@Component({
  selector: 'app-update-manager',
  templateUrl: './update-manager.component.html',
  styleUrls: ['./update-manager.component.css']
})
export class UpdateManagerComponent implements OnInit {
  id!:number;
  manager!: Manager;
  Umanager!:Observable<Manager>;
  mid!:string;

  constructor(private route: ActivatedRoute,private router: Router,
    private service: ManagerService) { }

  ngOnInit(): void {
    this.mid = this.route.snapshot.params['id'];
    this.id=Number.parseInt(this.mid);
    this.manager=new Manager(this.mid,"","");
    console.log(this.id);
    this.service.getManagerById(this.id).subscribe(data => {
      console.log(data);
      alert(data);
      this.manager=data;
    }, error => console.log(error));
  }
  onSubmit() {
    
    this.Umanager=this.service.updateManager(this.manager);
  this.Umanager.subscribe(data=>{alert("Please Enter Valid Data");},
  error => alert("Manager updated successfully."));
  this.router.navigate(['/viewManager']);
  }
  list(){
    this.router.navigate(['viewManager']);
  }


  }


