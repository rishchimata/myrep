export class User {
    constructor(
        //  public adminId:number,
         public userName:string,
         public password:string,
         public role:string
       
        ) {}
}
