import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { AddAdminComponent } from './add-admin/add-admin.component';
import { ViewAdminComponent } from './view-admin/view-admin.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http'
import { FormsModule } from '@angular/forms';
import { AdminService } from './adminservice/admin.service';
import { UpdateAdminComponent } from './update-admin/update-admin.component';
import { BasicAuthHtppInterceptorService } from './basic-auth-htpp-interceptor-service.service';

import { LoginComponent } from './login/login.component';
import { AddCompanyComponent } from './add-company/add-company.component';
import { AddManagerComponent } from './add-manager/add-manager.component';
import { AddUserComponent } from './add-user/add-user.component';
import { AddInvestorComponent } from './components/Investor/Add/add-investor.component';
import { BuyStockComponent } from './components/Investor/BuyStock/buy-stock.component';
import { InvestorDashboardComponent } from './components/Investor/Dashboard/investor-dashboard.component';
import { SellStockComponent } from './components/Investor/SellStock/sell-stock.component';
import { UpdateInvestorComponent } from './components/Investor/Update/update-investor.component';
import { ViewInvestorComponent } from './components/Investor/View/view-investor.component';
import { ViewInvestorByCompanyComponent } from './components/Investor/ViewByCompany/view-investor-by-company.component';
import { ViewInvestorByStockComponent } from './components/Investor/ViewByStock/view-investor-by-stock.component';
import { GrowingstockComponent } from './growingstock/growingstock.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { ReducingstockComponent } from './reducingstock/reducingstock.component';
import { InvestorService } from './services/Investor/investor.service';
import { StockComponent } from './stock/stock.component';
import { StockbycompanyComponent } from './stockbycompany/stockbycompany.component';
import { StockbyinvestorComponent } from './stockbyinvestor/stockbyinvestor.component';
import { UpdateCompanyComponent } from './update-company/update-company.component';
import { UpdateManagerComponent } from './update-manager/update-manager.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { UpdatestockComponent } from './updatestock/updatestock.component';
import { ViewCompanyComponent } from './view-company/view-company.component';
import { ViewManagerComponent } from './view-manager/view-manager.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { ViewstockComponent } from './viewstock/viewstock.component';
import { CompanyService } from './company.service';
import { ManagerService } from './manager.service';
import { RegisterComponent } from './register/register.component';
import { StockService } from './stock.service';


@NgModule({
  declarations: [
    AppComponent,
    StockComponent,
    UpdatestockComponent,
    ViewstockComponent,
    StockbyinvestorComponent,
    StockbycompanyComponent,
    GrowingstockComponent,
    ReducingstockComponent,
    AddManagerComponent,
    ViewManagerComponent,
    UpdateManagerComponent,
    AddCompanyComponent,
    ViewCompanyComponent,
    UpdateCompanyComponent,
    AddAdminComponent,
    ViewAdminComponent,
    UpdateAdminComponent,
    RegisterComponent,
    AddUserComponent,
    ViewUserComponent,
    UpdateUserComponent,
    InvestorDashboardComponent,
    AddInvestorComponent,
    ViewInvestorComponent,
    ViewInvestorByStockComponent,
    ViewInvestorByCompanyComponent,
    BuyStockComponent,
    SellStockComponent,
    UpdateInvestorComponent,
    MainpageComponent,
    LoginComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [AdminService,
    {  
      provide:HTTP_INTERCEPTORS, useClass:BasicAuthHtppInterceptorService, multi:true 
    },StockService,ManagerService,CompanyService,InvestorService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
