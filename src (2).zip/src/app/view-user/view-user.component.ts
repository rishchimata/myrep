import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {
  users:any;

  constructor(private service:UserService,private router: Router) { }

  ngOnInit(): void {
    let user=this.service.fetchUser();
    user.subscribe((data)=>this.users=data)
  }
public removeUser(id:number){
  let user=this.service.deleteUser(id);
  user.subscribe((data)=>this.users=data)
  location.reload();
}
updateUser(id:number):void{
  this.router.navigate(['updateUser',id]);
}

}
