import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Admin } from '../adminClass/admin';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
//  admin: Admin;
  constructor(private http:HttpClient) { }
 public insertAdmin(admin:any){
   alert(JSON.stringify(admin));
   let username='javajwt'
   let password='password'
 
   const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(username + ':' + password) });
   return this.http.post("http://localhost:9091/admin",admin,{responseType:'text',headers})
 }
 public fetchAdmin(){
   return this.http.get("http://localhost:9091/admin");
 }
 public deleteAdmin(id:number){
   return this.http.delete("http://localhost:9091/admin/"+id);
 }
 public  getAdminById(aid:number):Observable<Admin>{
  return this.http.get<Admin>("http://localhost:9091/admin/"+aid);
}
public updateAdmin(admin:Admin):Observable<Admin>
{
  return this.http.put<Admin>("http://localhost:9091/admin",admin);
}
}

