import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StockService } from '../stock.service';

@Component({
  selector: 'app-growingstock',
  templateUrl: './growingstock.component.html',
  styleUrls: ['./growingstock.component.css']
})
export class GrowingstockComponent implements OnInit {
  stock:any;
  constructor(private service:StockService,private router: Router) { }

  ngOnInit(): void {
    let stock=this.service.getGrowingStock();
    stock.subscribe((data)=>this.stock=data)
  }

}
