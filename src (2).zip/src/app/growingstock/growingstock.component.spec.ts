import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GrowingstockComponent } from './growingstock.component';

describe('GrowingstockComponent', () => {
  let component: GrowingstockComponent;
  let fixture: ComponentFixture<GrowingstockComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GrowingstockComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GrowingstockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
