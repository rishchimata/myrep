import { Component, OnInit } from '@angular/core';
import { Company } from '../company';
import { Stock } from '../stock';
import { StockService } from '../stock.service';

@Component({
  selector: 'app-stock',
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.css']
})
export class StockComponent implements OnInit {

  constructor(private service: StockService) { }
  company:Company=new Company(0,"");
  stock: Stock=new Stock(0,"",0,"NEUTRAL",0,0,0,"ACTIVE",this.company);
msg:any;
stocks:any;
  ngOnInit(): void {
  }

  public insert() {
    //alert (JSON.stringify(this.company));
    let response=this.service.insertStock(this.stock);
    response.subscribe((data)=>this.msg=data);
  

}
}