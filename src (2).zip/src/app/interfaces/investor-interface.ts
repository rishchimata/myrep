export interface InvestorInterface {
    bank:BankInterface;
    email: string;
    gender: string;
    investorId: number,
    investorName: string;
    mobileNo: number;
}

export interface BankInterface{
    accountNo: number;
    bankName: string;
    branchName: string;
    ifscCode: number;
}