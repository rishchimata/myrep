import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Company } from '../company';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-update-company',
  templateUrl: './update-company.component.html',
  styleUrls: ['./update-company.component.css']
})
export class UpdateCompanyComponent implements OnInit {

  id!:number;
  company!: Company;
  Ucompany!:Observable<Company>;
  cid!:string;
  constructor(private route: ActivatedRoute,private router: Router,
    private service: CompanyService) { }

  ngOnInit(): void {
    this.cid = this.route.snapshot.params['id'];
    this.id=Number.parseInt(this.cid);
    this.company=new Company(this.id,"");
    console.log(this.id);
    this.service.getCompanyById(this.id).subscribe(data => {
      console.log(data);
      //alert(data);
      this.company=data;
    }, error => console.log(error));
  }
  onSubmit() {
    this.Ucompany=this.service.updateCompany(this.company);
  this.Ucompany.subscribe(data=>{alert("Please Enter Valid Data");},
  error => alert("Company updated successfully."));
  this.router.navigate(['/viewcompany']);
  }
  list(){
    this.router.navigate(['viewcompany']);
  }


}
