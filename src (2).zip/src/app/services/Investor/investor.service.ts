import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Investor } from 'src/app/classes/investor';

@Injectable({
  providedIn: 'root'
})
export class InvestorService {

  //private static readonly POST_CUSTOMER_URL = '/api/post/customer';
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  
  constructor(private http:HttpClient) { }

  public add(investor:Investor): Observable<Investor> {
   
    return this.http.post<Investor>("http://localhost:9091/root/addInvestor",investor,{responseType:'text' as 'json'}); //{ headers: this.headers } //{responseType:'text' as 'json'}
  }

  public get():Observable<Investor[]>{
    return this.http.get<Investor[]>("http://localhost:9091/root/getAllInvestor");
  }

  public getById(investorId : number):Observable<Investor>{
    return this.http.get<Investor>("http://localhost:9091/root/getInvestorDetails/"+investorId);
  }
  
  public update(investor : Investor):Observable<Investor>{
    return this.http.put<Investor>("http://localhost:9091/root/updateInvestor",investor,{responseType:'text' as 'json'});
  }

  public delete( investorId : number):Observable<Investor>{
    return this.http.delete<Investor>("http://localhost:9091/root/deleteInvestorById/"+investorId,{responseType:'text' as 'json'});
  }

  public buy(stockId : number , investorId : number , quantity : number){
    return this.http.post("http://localhost:9091/root/buyStock/"+stockId+"/"+investorId+"/"+quantity,{responseType:'json'},{ headers: this.headers });
  } 

  public sell(stockId : number , investorId : number , quantity : number){
    return this.http.post("http://localhost:9091/root/sellStock/"+stockId+"/"+investorId+"/"+quantity,{responseType:'json'});
  } 

  public viewByStock(stockId : number):Observable<Investor[]>{
    return this.http.get<Investor[]>("http://localhost:9091/root/viewAllInvestorByStock/"+stockId);
  }

  public viewByCompany(companyId : number):Observable<Investor[]>{
    return this.http.get<Investor[]>("http://localhost:9091/root/viewAllInvestorByCompany/"+companyId);
  }
}   
