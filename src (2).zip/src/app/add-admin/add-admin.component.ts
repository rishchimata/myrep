import { Component, OnInit } from '@angular/core';
import { Admin } from '../adminClass/admin';
import { AdminService } from '../adminservice/admin.service';

@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.css']
})
export class AddAdminComponent implements OnInit {
admin: Admin=new Admin("","","");
msg:any;
  constructor(private service:AdminService) { }

  ngOnInit(): void {
  }
public insert() {
  let response=this.service.insertAdmin(this.admin);
  response.subscribe((data)=>this.msg=data);
}


}
