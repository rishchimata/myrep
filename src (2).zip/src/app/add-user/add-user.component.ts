import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  user: User=new User("","","");
  msg:any;
    constructor(private service:UserService) { }
  
    ngOnInit(): void {
    }
  public insert() {
    let response=this.service.insertUser(this.user);
    response.subscribe((data)=>this.msg=data);
  }

}
