export class Admin {
    constructor(
        //  public adminId:number,
         public adminName:string,
         public email:string,
         public password:string
       
        ) {}
}
