import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Admin } from '../adminClass/admin';
import { AdminService } from '../adminservice/admin.service';


@Component({
  selector: 'app-update-admin',
  templateUrl: './update-admin.component.html',
  styleUrls: ['./update-admin.component.css']
})
export class UpdateAdminComponent implements OnInit {
  id!:number;
  admin!: Admin;
  Uadmin!:Observable<Admin>;
  aid!:string;
  constructor(private route: ActivatedRoute,private router: Router,
    private service: AdminService) { }

  ngOnInit(): void {
    this.aid = this.route.snapshot.params['id'];
    this.id=Number.parseInt(this.aid);
    this.admin=new Admin(this.aid,"","");
    console.log(this.id);
    this.service.getAdminById(this.id).subscribe(data => {
      console.log(data);
      alert(data);
      this.admin=data;
    }, error => console.log(error));
  }
  onSubmit() {
    this.Uadmin=this.service.updateAdmin(this.admin);
  this.Uadmin.subscribe(data=>{alert("Please Enter Valid Data");},
  error => alert("Admin updated successfully."));
  this.router.navigate(['/viewAdmin']);
  }
  list(){
    this.router.navigate(['viewAdmin']);
  }

}
