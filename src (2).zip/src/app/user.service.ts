import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './user';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  public insertUser(user:any){
    alert(JSON.stringify(user));
    return this.http.post("http://localhost:9091/user",user,{responseType:'text'})
  }
  public fetchUser(){
    return this.http.get("http://localhost:9091/user");
  }
  public deleteUser(id:number){
    return this.http.delete("http://localhost:9091/user/"+id);
  }
  public  getUserById(uid:number):Observable<User>{
   return this.http.get<User>("http://localhost:9010/user/"+uid);
 }
 public updateUser(user:User):Observable<User>
 {
   return this.http.put<User>("http://localhost:9091/user",user);
 }
}
