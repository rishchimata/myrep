import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InvestorService } from 'src/app/services/Investor/investor.service';

@Component({
  selector: 'app-sell-stock',
  templateUrl: './sell-stock.component.html',
  styleUrls: ['./sell-stock.component.css']
})
export class SellStockComponent implements OnInit {

  stockId : number=0 ; 
  investorId : number=0 ;
  quantity : number=0;

  responseMsg:any;
  constructor(
    private investorSerice : InvestorService,
    private router : Router
  ) { }

  ngOnInit(): void {
  }

  onSubmit(stockId : number , investorId : number , quantity : number){
    let response=this.investorSerice.sell(stockId,investorId,quantity);
    response.subscribe((data) => this.responseMsg=data);
    this.router.navigate(['/investorDashboard']);
  }
  // sellStock(stockId : number , investorId : number , quantity : number){
  //   let response=this.investorSerice.sell(stockId,investorId,quantity);
  //   response.subscribe((data) => this.responseMsg=data);
  //   this.router.navigate(['/investorDashboard']);
  // }
}
