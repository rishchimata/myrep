import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Bank } from 'src/app/classes/bank';
import { Company } from 'src/app/classes/company';
import { Investor } from 'src/app/classes/investor';
import { Stock } from 'src/app/classes/stock';
import { InvestorService } from 'src/app/services/Investor/investor.service';

@Component({
  selector: 'app-buy-stock',
  templateUrl: './buy-stock.component.html',
  styleUrls: ['./buy-stock.component.css']
})
export class BuyStockComponent implements OnInit {

  responseMsg:any;

  company : Company={
                      companyId: 0,
                      companyName: ''
                    };
  
  stock : Stock={ 
                  avgPrice: 0,
                  company: this.company,
                  profitLoss: 0,
                  quantity: 0,
                  status: '',
                  stockId: 0,
                  stockName: '',
                  totalStocks: 0,
                  type: ''
                };

  bank:Bank={
              accountNo: 0,
              bankName: '',
              branchName: '',
              ifscCode: 0
            };
        
  investor : Investor={
                        account:this.bank,
                        email: '',
                        gender: '',
                        investorId: 0,
                        investorName: '',
                        mobileNo: 0};
  constructor(
              private investorService:InvestorService,
              private router:Router
  ) { }

  ngOnInit(): void {
  }

  onSubmit(stockId : number , investorId : number , quantity : number){
    alert("working")
    let response = this.investorService.buy(stockId,investorId,quantity);
    response.subscribe((msg) => this.responseMsg=msg);
    console.log(this.responseMsg)
    // alert(this.responseMsg);
    // alert(JSON.stringify(this.investor));
    this.router.navigate(['/investorDashboard']);
  }
  // buyStock(stockId : number , investorId : number , quantity : number){
  //   let response = this.investorService.buy(stockId,investorId,quantity);
  //   response.subscribe((msg) => this.responseMsg=msg);
  //   console.log(this.responseMsg)
  //   // alert(this.responseMsg);
  //   // alert(JSON.stringify(this.investor));
  //   this.router.navigate(['/investorDashboard']);
  // }
}
