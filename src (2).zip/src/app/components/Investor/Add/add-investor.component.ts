import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Bank } from 'src/app/classes/bank';
import { Investor } from 'src/app/classes/investor';
import { InvestorService } from 'src/app/services/Investor/investor.service';

@Component({
  selector: 'app-add-investor',
  templateUrl: './add-investor.component.html',
  styleUrls: ['./add-investor.component.css']
})
export class AddInvestorComponent implements OnInit {

  form:any;

  genders:any=[
    'MALE','FEMALE'
  ];
  selectedGender:string='';

  // account:number=Math.floor(100000 + Math.random() * 900000);
  // mobile:number=Math.floor(1000000000 + Math.random() * 9000000000);
  bank:Bank={accountNo: 0,
            bankName: '',
            branchName: '',
            ifscCode: 0};
  investor : Investor={account:this.bank,
                      email: '',
                      gender: '',
                      investorId: 0,
                      investorName: '',
                      mobileNo: 0};

  responseMsg:any;
  constructor(
              private investorService:InvestorService,
              private router:Router
            ) { }

  ngOnInit(): void {
    this.form=new FormGroup({
      "id":new FormControl(null),
      "name":new FormControl(null,[Validators.required,Validators.pattern('[a-zA-Z ]*')]),
      "email":new FormControl(null),
      "mobile":new FormControl(null),
      "branchName":new FormControl(null),
      "accountNumber":new FormControl(null),
      "ifsc":new FormControl(null)
    });
  }

  get name(){return this.form.get('name');}
  public genderChangeHandler(event : any){
    this.selectedGender=event.target.value;
  }

  onSubmit(){
    let response = this.investorService.add(this.investor);
    response.subscribe((msg) => this.responseMsg=msg);
    // alert(this.responseMsg);
    // alert(JSON.stringify(this.investor));
    this.router.navigate(['/investorDashboard']);
  }
  // public addInvestor(){
  //   let response = this.investorService.add(this.investor);
  //   response.subscribe((msg) => this.responseMsg=msg);
  //   // alert(this.responseMsg);
  //   // alert(JSON.stringify(this.investor));
  //   this.router.navigate(['/investorDashboard']);
  // }
}
