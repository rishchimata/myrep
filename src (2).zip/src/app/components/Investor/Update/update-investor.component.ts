import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Bank } from 'src/app/classes/bank';
import { Investor } from 'src/app/classes/investor';
import { InvestorInterface } from 'src/app/interfaces/investor-interface';
import { InvestorService } from 'src/app/services/Investor/investor.service';

@Component({
  selector: 'app-update-investor',
  templateUrl: './update-investor.component.html',
  styleUrls: ['./update-investor.component.css']
})
export class UpdateInvestorComponent implements OnInit {

  investorId:number=0;
  bank:Bank={accountNo: 0,
            bankName: '',
            branchName: '',
            ifscCode: 0};
investor : Investor={account:this.bank,
              email: '',
              gender: '',
              investorId: 0,
              investorName: '',
              mobileNo: 0};
  Uinvestor!: Observable<Investor>;
  iId:string='';

  genders:any=[
    'MALE','FEMALE'
  ];
  selectedGender:string='';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private investorService: InvestorService
  ) { }

  ngOnInit(): void {
    this.iId = this.route.snapshot.params['investorId'];
    this.investorId=Number.parseInt(this.iId);
    //this.investor=new InvestorInterface(this.cid,"","");
    console.log("investorId: "+this.investorId);
    this.investorService.getById(this.investorId).subscribe(data => {
      console.log(data)
      this.investor=data;
      this.bank=this.investor.account;
      console.log(JSON.stringify(this.investor));
    }, error => console.log(error)); 
  }

  public genderChangeHandler(event : any){
    this.selectedGender=event.target.value;
  }

  onSubmit(){
    this.Uinvestor=this.investorService.update(this.investor);
  this.Uinvestor.subscribe(data=>{alert("Coder updated successfully.");},
  error => alert("Coder does not exist in the database cannot be updated"));
  this.router.navigate(['/getAllInvestor']);
  }
  // public updateInvestor(){
  //   this.Uinvestor=this.investorService.update(this.investor);
  // this.Uinvestor.subscribe(data=>{alert("Coder updated successfully.");},
  // error => alert("Coder does not exist in the database cannot be updated"));
  // this.router.navigate(['/getAllInvestor']);
  // }
}
