import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewInvestorByStockComponent } from './view-investor-by-stock.component';

describe('ViewInvestorByStockComponent', () => {
  let component: ViewInvestorByStockComponent;
  let fixture: ComponentFixture<ViewInvestorByStockComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewInvestorByStockComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewInvestorByStockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
