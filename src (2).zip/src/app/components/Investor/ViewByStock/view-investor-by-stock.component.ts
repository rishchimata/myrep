import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Investor } from 'src/app/classes/investor';
import { InvestorService } from 'src/app/services/Investor/investor.service';

@Component({
  selector: 'app-view-investor-by-stock',
  templateUrl: './view-investor-by-stock.component.html',
  styleUrls: ['./view-investor-by-stock.component.css']
})
export class ViewInvestorByStockComponent implements OnInit {

  stockId:number=0;

  investor =new Observable<Investor[]>();
  investors:Investor[]=[];
  constructor(
              private investorService:InvestorService,
              private router:Router
  ) { }

  ngOnInit(): void {
  }

  onSubmit(){
    this.investor=this.investorService.viewByStock(this.stockId);
    this.investor.subscribe((data) => this.investors=data);
  }
  // viewInvestorByStock():void{
    
  // }
}
