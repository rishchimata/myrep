import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, observable } from 'rxjs';
import { Investor } from 'src/app/classes/investor';
import { InvestorService } from 'src/app/services/Investor/investor.service';

@Component({
  selector: 'app-view-investor-by-company',
  templateUrl: './view-investor-by-company.component.html',
  styleUrls: ['./view-investor-by-company.component.css']
})
export class ViewInvestorByCompanyComponent implements OnInit {

  companyId:number=0;
  investor=new Observable<Investor[]>();
  investors:Investor[]=[];

  constructor(
    private investorService:InvestorService,
    private router:Router
  ) { }

  ngOnInit(): void {
  }

  onSubmit():void{
    this.investor=this.investorService.viewByCompany(this.companyId);
    this.investor.subscribe((data) => this.investors=data);
  }
  // viewInvestorByCompany():void{
  //   this.investor=this.investorService.viewByCompany(this.companyId);
  //   this.investor.subscribe((data) => this.investors=data);
  // }
}
