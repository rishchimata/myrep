import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewInvestorByCompanyComponent } from './view-investor-by-company.component';

describe('ViewInvestorByCompanyComponent', () => {
  let component: ViewInvestorByCompanyComponent;
  let fixture: ComponentFixture<ViewInvestorByCompanyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewInvestorByCompanyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewInvestorByCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
