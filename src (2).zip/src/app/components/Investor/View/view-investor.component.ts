import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { InvestorService } from 'src/app/services/Investor/investor.service';
import { InvestorInterface } from 'src/app/interfaces/investor-interface';
import { Investor } from 'src/app/classes/investor';
import { Bank } from 'src/app/classes/bank';

@Component({
  selector: 'app-view-investor',
  templateUrl: './view-investor.component.html',
  styleUrls: ['./view-investor.component.css']
})
export class ViewInvestorComponent implements OnInit {

  investor = new Observable<Investor[]>();
  investors:Investor[]=[];
  bank:Bank={accountNo: 0,
    bankName: '',
    branchName: '',
    ifscCode: 0};
Dinvestor =new Observable<Investor>();
  constructor(
    private investorService:InvestorService,
    private router:Router
  ) { }

  ngOnInit(): void {
    this.investor=this.investorService.get();
    this.investor.subscribe((data) => this.investors=data);
  }

  updateInvestor(investorId:number):void{
    this.router.navigate(['getInvestorDetails/',investorId]);
  }

  deleteInvestor(investorId : number){
    this.Dinvestor=this.investorService.delete(investorId);
    alert("Investor deleted Successfully");
    location.reload();
    this.Dinvestor.subscribe(()=>this.investorService.get()); 
  }
}
