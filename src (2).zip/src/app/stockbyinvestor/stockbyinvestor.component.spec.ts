import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StockbyinvestorComponent } from './stockbyinvestor.component';

describe('StockbyinvestorComponent', () => {
  let component: StockbyinvestorComponent;
  let fixture: ComponentFixture<StockbyinvestorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StockbyinvestorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StockbyinvestorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
