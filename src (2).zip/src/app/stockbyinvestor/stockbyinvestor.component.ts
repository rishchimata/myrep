import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stockbyinvestor',
  templateUrl: './stockbyinvestor.component.html',
  styleUrls: ['./stockbyinvestor.component.css']
})
export class StockbyinvestorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
