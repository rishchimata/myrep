import { Component, OnInit } from '@angular/core';
import { Manager } from '../manager';
import { ManagerService } from '../manager.service';

@Component({
  selector: 'app-add-manager',
  templateUrl: './add-manager.component.html',
  styleUrls: ['./add-manager.component.css']
})
export class AddManagerComponent implements OnInit {
  companys:any;
  manager: Manager=new Manager("","","");
  msg:any;
    constructor(private service:ManagerService) { }
  
    ngOnInit(): void {
      let company=this.service.fetchCompany();
      company.subscribe((data)=>this.companys=data)
    }
  public insert() {
    let response=this.service.insertManager(this.manager);
    response.subscribe((data)=>this.msg=data);
  }
}
