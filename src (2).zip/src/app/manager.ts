export class Manager {
    constructor(
        //  public adminId:number,
         public managerName:string,
         public email:string,
         public mobileNo:string
       
        ) {}


}
