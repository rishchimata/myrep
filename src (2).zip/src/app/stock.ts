import { Company } from "./company";

export class Stock {
    constructor(
        public stockId:number,
        public stockName:string,
        public quantity:number,
        public type:string, 
        public avgPrice:number,
        public totalStocks:number,
        public profitLoss:number,
        public status:string,
        public company:Company
        ) {}
}
