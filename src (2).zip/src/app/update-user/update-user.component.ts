import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {

  id!:number;
  user!: User;
  Uuser!:Observable<User>;
  uid!:string;
  constructor(private route: ActivatedRoute,private router: Router,
    private service: UserService) { }

  ngOnInit(): void {
    this.uid = this.route.snapshot.params['id'];
    this.id=Number.parseInt(this.uid);
    this.user=new User(this.uid,"","");
    console.log(this.id);
    this.service.getUserById(this.id).subscribe(data => {
      console.log(data);
      alert(data);
      this.user=data;
    }, error => console.log(error));
  }
  onSubmit() {
    this.Uuser=this.service.updateUser(this.user);
  this.Uuser.subscribe(data=>{alert("Please Enter Valid Data");},
  error => alert("User updated successfully."));
  this.router.navigate(['/viewUser']);
  }
  list(){
    this.router.navigate(['viewUser']);
  }

}
